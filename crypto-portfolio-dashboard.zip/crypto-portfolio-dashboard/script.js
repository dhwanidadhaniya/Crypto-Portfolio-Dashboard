const tokens = [
  { id: 1, name: 'Bitcoin', symbol: 'BTC', balance: 1.5, price: 50000 },
  { id: 2, name: 'Ethereum', symbol: 'ETH', balance: 10, price: 4000 },
  { id: 3, name: 'Ripple', symbol: 'XRP', balance: 2000, price: 1 },
  { id: 4, name: 'Litecoin', symbol: 'LTC', balance: 20, price: 150 },
];

const tokenListElement = document.getElementById('token-list');
const totalValueElement = document.getElementById('total-value');
const chartElement = document.getElementById('portfolioChart');

let chart;

function updateTotalPortfolioValue() {
  const totalValue = tokens.reduce((sum, token) => sum + token.balance * token.price, 0);
  totalValueElement.textContent = totalValue.toFixed(2);
}

function updatePieChart() {
  const data = tokens.map(token => token.balance * token.price);
  const labels = tokens.map(token => token.name);

  if (chart) {
    chart.data.datasets[0].data = data;
    chart.update();
  } else {
    chart = new Chart(chartElement, {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
        }]
      },
    });
  }
}

function renderTokens() {
  tokenListElement.innerHTML = ''; // Clear previous tokens

  tokens.forEach(token => {
    const tokenElement = document.createElement('div');
    tokenElement.className = 'token-item';

    tokenElement.innerHTML = `
      <span>${token.name} (${token.symbol})</span>
      <span>${token.balance} @ $${token.price} = $${(token.balance * token.price).toFixed(2)}</span>
      <div class="token-actions">
        <button onclick="buyToken(${token.id})">Buy</button>
        <button onclick="sellToken(${token.id})" ${token.balance <= 0 ? 'disabled' : ''}>Sell</button>
      </div>
    `;

    tokenListElement.appendChild(tokenElement);
  });

  updateTotalPortfolioValue();
  updatePieChart();
}

function buyToken(id) {
  const token = tokens.find(t => t.id === id);
  if (token) {
    token.balance += 1;
    renderTokens();
  }
}

function sellToken(id) {
  const token = tokens.find(t => t.id === id);
  if (token && token.balance > 0) {
    token.balance -= 1;
    renderTokens();
  }
}

// Initialize the dashboard
renderTokens();

